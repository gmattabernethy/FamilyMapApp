package com.example.matt.familymap.tool;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Data {
    static private Data data;

    private String authToken;
    private String server;
    private Gson gson = new Gson();

    private Data() {

    }

    public static Data buildData() {
        if (data == null) data = new Data();
        return data;
    }
}

